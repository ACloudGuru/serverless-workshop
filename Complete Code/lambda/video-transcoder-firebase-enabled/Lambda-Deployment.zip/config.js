var env={};
env.ELASTIC_TRANSCODER_REGION = 'us-east-1';
env.ELASTIC_TRANSCODER_PIPELINE_ID = '1451470066051-jscnci';
env.FIREBASE_URL = 'https://intense-heat-7654.firebaseio.com';
env.FIREBASE_SECRET = 'tuOorDLFVkMv3H6uXrWxsOv3YXRn20ml22Ggusuu';
module.exports = env;

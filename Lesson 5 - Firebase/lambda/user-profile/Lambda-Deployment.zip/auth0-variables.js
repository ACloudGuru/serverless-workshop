var env={};
env.AUTH0_SECRET='wQWsk6DxwAv6ZM5nfwssXvV58ncJ_2Vc6PcFktgDE27MdZ3O0_heOtdpCUAcbvQO';
env.AUTH0_DOMAIN='samkroon.auth0.com';
module.exports = env;

var env={};
env.AUTH0_SECRET='wQWsk6DxwAv6ZM5nfwssXvV58ncJ_2Vc6PcFktgDE27MdZ3O0_heOtdpCUAcbvQO';
module.exports = env;

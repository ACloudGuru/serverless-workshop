var env={};
env.BUCKET_REGION = 'us-east-1';
env.FIREBASE_URL = 'https://intense-heat-7654.firebaseio.com';
env.FIREBASE_SECRET = 'tuOorDLFVkMv3H6uXrWxsOv3YXRn20ml22Ggusuu';
module.exports = env;
